/*******************************************************************************
* Copyright (c) 2025
* Georgia Institute of Technology
* 
* This source code is part of NeuroSim (NS)-Cache - a framework developed for early
* exploration of cache memories in advanced technology nodes (FinFET, nanosheet, CFET generations).
* The tool extends previously developed Destiny, NVSim, and Cacti3dd. (Copyright Information Below)
* Copyright of the model is maintained by the developers, and the model is distributed under 
* the terms of the Creative Commons Attribution-NonCommercial 4.0 International Public License (see LICENSE)
*******************************************************************************/

// This file contains code from NVSim, (c) 2012-2013,  Pennsylvania State University 
//and Hewlett-Packard Company. See LICENSE_NVSim file in the top-level directory.
//No part of DESTINY Project, including this file, may be copied,
//modified, propagated, or distributed except according to the terms
//contained in the LICENSE file.


#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <math.h>
#include <cassert>
#include "InputParameter.h"
#include "MemCell.h"
#include "RowDecoder.h"
#include "Precharger.h"
#include "OutputDriver.h"
#include "SenseAmp.h"
#include "Technology.h"
#include "BasicDecoder.h"
#include "PredecodeBlock.h"
#include "Mat.h"
#include "SubArray.h"
#include "BankWithHtree.h"
#include "BankWithoutHtree.h"
#include "Wire.h"
#include "Result.h"
#include "formula.h"
#include "macros.h"
#include "TSV.h"

using namespace std;

InputParameter *inputParameter;
Technology *tech;
Technology *devtech;
MemCell *cell;
Wire *localWire;
Wire *globalWire;
MemCell **sweepCells;

int numRowMat, numColumnMat;

void applyConstraint();
void initializeTechnology(Technology *target, int processNode, DeviceRoadmap deviceRoadmap);
int nvsim(ofstream& outputFile, string inputFileName, long long& numSolution, Result *bestDataResults, Result *bestTagResults);

void tsvVerif(InputParameter *inputParameter)
{
    int techNodes[] = {90,65,45,32,22,14,10,7,5,3,2,1};
    int nodeCount = 12;
    bool interpolate = true;
    bool buffered = false;

    // 4 types of TSVs at each node
    // -- Aggressive interconnect, ITRS projection
    // -- Conservative interconnect, ITRS projection
    // -- Aggressive interconnect, Industry reported
    // -- Conservative interconnect, Industry reported
    for (int wiretype = 0; wiretype < 2; wiretype++) {
        for (int layers = 2; layers <= 16; layers *= 2) {
            for (int node = 0; node < nodeCount; node++) {

                // 0 -- Aggressive, 1 -- Conservative
                inputParameter->maxLocalWireType = wiretype;
                inputParameter->maxGlobalWireType = wiretype;
                
                // 0 -- ITRS, 1 -- Industry Reported
                inputParameter->localTsvProjection = 0;
                inputParameter->globalTsvProjection = 1;

                tech = new Technology();
                tech->Initialize(techNodes[node], HP, inputParameter);
                tech->SetLayerCount(inputParameter, layers);

                if (interpolate) {
                    Technology techHigh;
                    double alpha = 0;
                    if (techNodes[node] > 65) { // 65 nm < technology node <= 90 nm
                        techHigh.Initialize(90, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 65.0) / 25;
                    } else if (techNodes[node] > 45) { // 45 nm < technology node <= 65 nm
                        techHigh.Initialize(65, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 45.0) / 20;
                    } else if (techNodes[node] >= 32) { // 32 nm < technology node <= 45 nm
                        techHigh.Initialize(45, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 32.0) / 13;
                    } else if (techNodes[node] >= 22) { // 22 nm < technology node <= 32 nm
                        techHigh.Initialize(32, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 22.0) / 10;
                    } else if (techNodes[node] >= 14) { // 14 nm < technology node <= 22 nm
                        techHigh.Initialize(22, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 14.0) / 8;
					} else if (techNodes[node] >= 10) { // 10 nm < technology node <= 14 nm
                        techHigh.Initialize(14, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 10.0) / 4;
					} else if (techNodes[node] >= 7) { // 7 nm < technology node <= 10 nm
                        techHigh.Initialize(10, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 7.0) / 3;
					} else if (techNodes[node] >= 5) { // 5 nm < technology node <= 7 nm
                        techHigh.Initialize(7, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 5.0) / 2;
					} else if (techNodes[node] >= 3) { // 3 nm < technology node <= 5 nm
                        techHigh.Initialize(5, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 3.0) / 2;
					} else if (techNodes[node] >= 2) { // 2 nm < technology node <= 3 nm
                        techHigh.Initialize(3, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 2.0) / 1;
					} else if (techNodes[node] >= 1) { // 1 nm < technology node <= 2 nm
                        techHigh.Initialize(2, inputParameter->deviceRoadmap, inputParameter);
                        alpha = (techNodes[node] - 1.0) / 1;
					}

                    tech->InterpolateWith(techHigh, alpha);
                }

                TSV tsv1;

                tsv1.Initialize(Fine, buffered);
                tsv1.CalculateArea();
                tsv1.CalculateLatencyAndPower(infinite_ramp, infinite_ramp);

                TSV tsv2;

                tsv2.Initialize(Coarse, buffered);
                tsv2.CalculateArea();
                tsv2.CalculateLatencyAndPower(infinite_ramp, infinite_ramp);

                cout << layers << "," << techNodes[node] << "," << wiretype << ",0,"
                     << tsv1.res << "," << tsv1.cap * 1e12 << "e-12," << tsv1.C_load_TSV * 1e12 << "e-12," << tsv1.num_gates << ","
                     << tsv1.area * 1e12 << "e-12," << tsv1.readDynamicEnergy * 1e12 << "e-12,"
                     << tsv1.readLatency * 1e12 << "e-12," << tsv1.leakage * 1e12 << endl; 
                cout << layers << "," << techNodes[node] << "," << wiretype << ",1,"
                     << tsv2.res << "," << tsv2.cap * 1e12 << "e-12," << tsv2.C_load_TSV * 1e12 << "e-12," << tsv2.num_gates << ","
                     << tsv2.area * 1e12 << "e-12," << tsv2.readDynamicEnergy * 1e12 << "e-12,"
                     << tsv2.readLatency * 1e12 << "e-12," << tsv2.leakage * 1e12 << endl; 
            }
        }
    }

    exit(0);
}

int main(int argc, char *argv[])
{
	cout << fixed << setprecision(3);
	string inputFileName;

	if (argc == 1) {
		inputFileName = "nvsim.cfg";
		cout << "Default configuration file (nvsim.cfg) is loaded" << endl;
	} else {
		inputFileName = argv[1];
		cout << "User-defined configuration file (" << inputFileName << ") is loaded" << endl;
	}
	cout << endl;

	inputParameter = new InputParameter();
	RESTORE_SEARCH_SIZE;
	inputParameter->ReadInputParameterFromFile(inputFileName);

    //tsvVerif(inputParameter);

	tech = new Technology();
	initializeTechnology(tech, inputParameter->processNode, inputParameter->deviceRoadmap);

	/* NS-Cache Warning for New Users for NeuroSim Infrastructure */
	if (inputParameter->temperature > 300 && inputParameter->processNode < 22) cout << "WARNING: NeuroSim sub-22nm nodes on-current only calibrated for room temperature. [V.1.0]\n" << endl;

    /* Open output file for full_exploration. */
    ofstream outputFile;
	string outputFileName;
	if (inputParameter->optimizationTarget == full_exploration) {
		/*stringstream temp;
		temp << inputParameter->outputFilePrefix << "_" << inputParameter->capacity / 1024 << "K_" << inputParameter->wordWidth
				<< "_" << inputParameter->associativity;
		if (inputParameter->internalSensing)
			temp << "_IN";
		else
			temp << "_EX";
		//if (cell->readMode)
		//	temp << "_VOL";
		//else
		//	temp << "_CUR";
		temp << ".csv";
		outputFileName = temp.str();*/
        int extIdx = inputFileName.find_last_of("."); 
        outputFileName = inputFileName.substr(0, extIdx) + ".csv";
		outputFile.open(outputFileName.c_str(), ofstream::out | ofstream::trunc);
        if (!outputFile.is_open()) {
            cout << "Could not open file " << outputFileName << "!" << endl;
            exit(-1);
        }
	}

    int numCellTypes = inputParameter->fileMemCell.size();
    sweepCells = new MemCell*[numCellTypes];

    Result **bestDataResults = new Result * [numCellTypes];
    Result **bestTagResults = new Result * [numCellTypes];

    /* Parse and validate every requested cell before exploring any design.
     * In particular, a malformed AOS cell later in a multi-cell sweep must not
     * fail only after earlier technologies have already been explored. */
    for (int cellIdx = 0; cellIdx < numCellTypes; cellIdx++) {
        sweepCells[cellIdx] = new MemCell();
        cell = sweepCells[cellIdx];
        cell->ReadCellFromFile(inputParameter->fileMemCell[cellIdx]);
        cell->ApplyPVT();
    }

    int failures = 0;
    long long totalSolutions = 0;
    for (int cellIdx = 0; cellIdx < numCellTypes; cellIdx++) {
        long long solutions = 0;
    //	cell->CellScaling(inputParameter->processNode);
        cell = sweepCells[cellIdx];

        /* Standalone DRAM uses the selected peripheral device roadmap.  eDRAM
         * alone has a dedicated embedded-access-device table in Technology. */
        devtech = tech;

        if (cell->memCellType == eDRAM) {
            devtech = new Technology();
            initializeTechnology(devtech, inputParameter->processNode, EDRAM);
        }

        if (cellIdx == 0) // Print once only
            inputParameter->PrintInputParameter();

        cout << "Using cell file: " << inputParameter->fileMemCell[cellIdx] << endl;
    
        bestDataResults[cellIdx] = new Result[(int)full_exploration];
        bestTagResults[cellIdx] = new Result[(int)full_exploration];

        /* Find the best solutions, pruned solutions, or all solutions for this cell type. */
        if (nvsim(outputFile, inputFileName, solutions, bestDataResults[cellIdx], bestTagResults[cellIdx])) {
            failures++;
        } else {
            totalSolutions += solutions;
        }

        if (cell->memCellType == eDRAM) {
            delete devtech;
        }
    }
    cout << "[Info] Cell exploration failures: " << failures << " / " << numCellTypes << endl;

    /* Compare against results from previous cell types. */
    if (inputParameter->optimizationTarget == full_exploration 
        && inputParameter->isPruningEnabled
        && inputParameter->doublePrune) {
        /* Pick the best of the best over all the cell types for each x,y,z pruning triple. */
    } else if (inputParameter->optimizationTarget != full_exploration) {
        /* Pick the best of the best for each optimization target. */
        for (int cellIdx = 1; cellIdx < numCellTypes; cellIdx++) {
            for (int tgtIdx = 0; tgtIdx < (int)full_exploration; tgtIdx++) {
                bool updated = bestDataResults[0][tgtIdx].compareAndUpdate(bestDataResults[cellIdx][tgtIdx]);
                
                if (updated && !inputParameter->allowDifferentTagTech) {
                    /* Make sure these match the case in compareAndUpdate. */
                    *(bestTagResults[0][tgtIdx].bank) = *(bestTagResults[cellIdx][tgtIdx].bank);
                    *(bestTagResults[0][tgtIdx].localWire) = *(bestTagResults[cellIdx][tgtIdx].localWire);
                    *(bestTagResults[0][tgtIdx].globalWire) = *(bestTagResults[cellIdx][tgtIdx].globalWire);
                    bestDataResults[0][tgtIdx].cellTech = sweepCells[cellIdx];
                    bestTagResults[0][tgtIdx].cellTech = sweepCells[cellIdx];
                } else if (updated && inputParameter->allowDifferentTagTech) {
                    bestDataResults[0][tgtIdx].cellTech = sweepCells[cellIdx];
                }

                /* Find the best tag for each target as well. */
                if (inputParameter->allowDifferentTagTech) {
                    updated = bestTagResults[0][tgtIdx].compareAndUpdate(bestTagResults[cellIdx][tgtIdx]);
                    if (updated) 
                        bestTagResults[0][tgtIdx].cellTech = sweepCells[cellIdx];
                }
            }
        }
    }

	if (inputParameter->optimizationTarget != full_exploration) {
		if (totalSolutions > 0 && !inputParameter->printAllOptimals) {
            cell = bestDataResults[0][inputParameter->optimizationTarget].cellTech;
            //cell->PrintCell();

			if (inputParameter->designTarget == cache)
				bestDataResults[0][inputParameter->optimizationTarget].printAsCache(bestTagResults[0][inputParameter->optimizationTarget], inputParameter->cacheAccessMode);
			else
				bestDataResults[0][inputParameter->optimizationTarget].print();
        } else if (totalSolutions > 0) {
            //cell->PrintCell();

            for (int tgtIdx = 0; tgtIdx < (int)full_exploration; tgtIdx++) {
                cell = bestDataResults[0][tgtIdx].cellTech;

                if (inputParameter->designTarget == cache)
                    bestDataResults[0][tgtIdx].printAsCache(bestTagResults[0][tgtIdx], inputParameter->cacheAccessMode);
                else
                    bestDataResults[0][tgtIdx].print();
            } 
		} else {
			cout << "No valid solutions." << endl;
		}
		cout << endl << "Finished!" << endl;
	} else {
		cout << endl << outputFileName << " generated successfully!" << endl;
		if (inputParameter->isPruningEnabled) {
			cout << "The results are pruned" << endl;
		} else {
			int solutionMultiplier = 1;
			if (inputParameter->designTarget == cache)
				solutionMultiplier = 8;
			cout << totalSolutions * solutionMultiplier << " solutions in total" << endl;
		}
	}

	return 0;
}

void initializeTechnology(Technology *target, int processNode, DeviceRoadmap deviceRoadmap)
{
	target->Initialize(processNode, deviceRoadmap, inputParameter);

	Technology techHigh;
	double alpha = 0;
	bool interpolate = true;
	if (processNode > 200){
		interpolate = false;
	} else if (processNode > 120) { // 120 nm < technology node <= 200 nm
		techHigh.Initialize(200, deviceRoadmap, inputParameter);
		alpha = (processNode - 120.0) / 60;
	} else if (processNode > 90) { // 90 nm < technology node <= 120 nm
		techHigh.Initialize(120, deviceRoadmap, inputParameter);
		alpha = (processNode - 90.0) / 30;
	} else if (processNode > 65) { // 65 nm < technology node <= 90 nm
		techHigh.Initialize(90, deviceRoadmap, inputParameter);
		alpha = (processNode - 65.0) / 25;
	} else if (processNode > 45) { // 45 nm < technology node <= 65 nm
		techHigh.Initialize(65, deviceRoadmap, inputParameter);
		alpha = (processNode - 45.0) / 20;
	} else if (processNode >= 32) { // 32 nm < technology node <= 45 nm
		techHigh.Initialize(45, deviceRoadmap, inputParameter);
		alpha = (processNode - 32.0) / 13;
	} else if (processNode >= 22) { // 22 nm < technology node <= 32 nm
		techHigh.Initialize(32, deviceRoadmap, inputParameter);
		alpha = (processNode - 22.0) / 10;
	} else if (processNode >= 14) { // 14 nm < technology node <= 22 nm
		techHigh.Initialize(22, deviceRoadmap, inputParameter);
		alpha = (processNode - 14.0) / 8;
	} else if (processNode >= 10) { // 10 nm < technology node <= 14 nm
		techHigh.Initialize(14, deviceRoadmap, inputParameter);
		alpha = (processNode - 10.0) / 4;
	} else if (processNode >= 7) { // 7 nm < technology node <= 10 nm
		techHigh.Initialize(10, deviceRoadmap, inputParameter);
		alpha = (processNode - 7.0) / 3;
	} else if (processNode >= 5) { // 5 nm < technology node <= 7 nm
		techHigh.Initialize(7, deviceRoadmap, inputParameter);
		alpha = (processNode - 5.0) / 2;
	} else if (processNode >= 3) { // 3 nm < technology node <= 5 nm
		techHigh.Initialize(5, deviceRoadmap, inputParameter);
		alpha = (processNode - 3.0) / 2;
	} else if (processNode >= 2) { // 2 nm < technology node <= 3 nm
		techHigh.Initialize(3, deviceRoadmap, inputParameter);
		alpha = (processNode - 2.0) / 1;
	} else if (processNode >= 1) { // 1 nm < technology node <= 2 nm
		techHigh.Initialize(2, deviceRoadmap, inputParameter);
		alpha = (processNode - 1.0) / 1;
	} else {
		interpolate = false;
	}

	if (interpolate) {
		target->InterpolateWith(techHigh, alpha);
	}
}

int nvsim(ofstream& outputFile, string inputFileName, long long& numSolution, Result *bestDataResults, Result *bestTagResults)
{
	applyConstraint();

	int numRowSubArray, numColumnSubArray, numActiveSubArrayPerRow, numActiveSubArrayPerColumn;
	int numActiveMatPerRow, numActiveMatPerColumn;
	int muxSenseAmp, muxOutputLev1, muxOutputLev2, numRowPerSet;
	int areaOptimizationLevel;							/* actually BufferDesignTarget */
	int localWireType, globalWireType;					/* actually WireType */
	int localWireRepeaterType, globalWireRepeaterType;	/* actually WireRepeaterType */
	int isLocalWireLowSwing, isGlobalWireLowSwing;		/* actually boolean value */
    int stackedDieCount, partitionGranularity;

	long long capacity;
	long blockSize;
	int associativity;

    long long numDesigns = 0;

	/* for cache data array, memory array */
	//Result *bestDataResults = new Result[(int)full_exploration];	/* full_exploration is always set as the last element in the enum, so if full_exploration is 8, what we want here is a 0-7 array, which is correct */
	Bank *dataBank;
	for (int i = 0; i < (int)full_exploration; i++) {
		bestDataResults[i].optimizationTarget = (OptimizationTarget)i;
        bestDataResults[i].cellTech = cell;
    }

	/* for cache tag array only */
	//Result *bestTagResults = new Result[(int)full_exploration];	/* full_exploration is always set as the last element in the enum, so if full_exploration is 8, what we want here is a 0-7 array, which is correct */
	Bank *tagBank = NULL;
	for (int i = 0; i < (int)full_exploration; i++) {
		bestTagResults[i].optimizationTarget = (OptimizationTarget)i;
        bestTagResults[i].cellTech = cell;
    }

	localWire = new Wire();
	globalWire = new Wire();

    partitionGranularity = inputParameter->partitionGranularity;

	/* search tag first */
	if (inputParameter->designTarget == cache) {
		/* need to design the tag array */
		REDUCE_SEARCH_SIZE;
		/* calculate the tag configuration */
		int numDataSet = inputParameter->capacity * 8 / inputParameter->wordWidth / inputParameter->associativity;
		int numIndexBit = (int)(log2(numDataSet) + 0.1);
		int numOffsetBit = (int)(log2(inputParameter->wordWidth / 8) + 0.1);
		INITIAL_BASIC_WIRE;
		/* Simulate tag */
		BIGFOR {
            tech->SetLayerCount(inputParameter, stackedDieCount);
			blockSize = TOTAL_ADDRESS_BIT - numIndexBit - numOffsetBit;
			blockSize += 2;		/* add dirty bits and valid bits */
			if (blockSize / (numActiveSubArrayPerRow * numActiveSubArrayPerColumn * numActiveMatPerRow * numActiveMatPerColumn) == 0) {
				/* To aggressive partitioning */
				continue;
			}
			if (blockSize % (numActiveSubArrayPerRow * numActiveSubArrayPerColumn * numActiveMatPerRow * numActiveMatPerColumn)) {
				blockSize = (blockSize / (numActiveSubArrayPerRow * numActiveSubArrayPerColumn * numActiveMatPerRow * numActiveMatPerColumn) + 1)
						* (numActiveSubArrayPerRow * numActiveSubArrayPerColumn * numActiveMatPerRow * numActiveMatPerColumn);
			}
			capacity = (long long)inputParameter->capacity * 8 / inputParameter->wordWidth * blockSize;
			associativity = inputParameter->associativity;
			CALCULATE(tagBank, MemoryType::tag);
            numDesigns++;
			if (!tagBank->invalid) {
				Result tempResult;
				VERIFY_TAG_CAPACITY;
				numSolution++;
				UPDATE_BEST_TAG;
			}
			delete tagBank;
		}

		if (numSolution > 0) {
			Bank * trialBank;
			Result tempResult;
			/* refine local wire type */
			REFINE_LOCAL_WIRE_FORLOOP {
				localWire->Initialize(inputParameter->processNode, (WireType)localWireType,
						(WireRepeaterType)localWireRepeaterType, inputParameter->temperature,
						(bool)isLocalWireLowSwing);
				for (int i = 0; i < (int)full_exploration; i++) {
					LOAD_GLOBAL_WIRE(bestTagResults[i]);
					TRY_AND_UPDATE(bestTagResults[i], MemoryType::tag);
				}
			}
			/* refine global wire type */
			REFINE_GLOBAL_WIRE_FORLOOP {
				globalWire->Initialize(inputParameter->processNode, (WireType)globalWireType,
						(WireRepeaterType)globalWireRepeaterType, inputParameter->temperature,
						(bool)isGlobalWireLowSwing);
				for (int i = 0; i < (int)full_exploration; i++) {
					LOAD_LOCAL_WIRE(bestTagResults[i]);
					TRY_AND_UPDATE(bestTagResults[i], MemoryType::tag);
				}
			}
		}

		if (numSolution == 0) {
			cout << "No valid solutions for tags." << endl;
			cout << endl << "Finished!" << endl;
			if (localWire) delete localWire;
			if (globalWire) delete globalWire;
			//outputFile.close();
			return 1;
		} else {
			numSolution = 0;
            numDesigns = 0;
			RESTORE_SEARCH_SIZE;
			inputParameter->ReadInputParameterFromFile(inputFileName);	/* just for restoring the search space */
			applyConstraint();
		}
	}

	/* adjust cache data array parameters according to the access mode */
	capacity = (long long)inputParameter->capacity * 8;
	blockSize = inputParameter->wordWidth;
	associativity = inputParameter->associativity;
	if (inputParameter->designTarget == cache) {
		switch (inputParameter->cacheAccessMode) {
		case sequential_access_mode:
			/* already knows which way to access */
			associativity = 1;
			break;
		case fast_access_mode:
			/* load the entire set as a single word */
			blockSize *= associativity;
			associativity = 1;
			break;
		default:	/* Normal */
			/* Normal access does not allow one set be distributed into multiple rows
			 * otherwise, the row activation has to be delayed until the hit signals arrive.
			 */
			inputParameter->minNumRowPerSet = inputParameter->maxNumRowPerSet = 1;
		}
	}

	/* adjust block size is it is SLC NAND flash or DRAM memory chip */
	if (inputParameter->designTarget == RAM_chip && (cell->memCellType == SLCNAND || cell->memCellType == DRAM)) {
		blockSize = inputParameter->pageSize;
		associativity = 1;
	}

	INITIAL_BASIC_WIRE;
	BIGFOR {
		if (blockSize / (numActiveSubArrayPerRow * numActiveSubArrayPerColumn * numActiveMatPerRow * numActiveMatPerColumn) == 0) {
			/* To aggressive partitioning */
			continue;
		}
        //if (capacity / (numRowSubArray * numColumnSubArray * numRowMat * numColumnMat) < 32*32) {
        //    // Require at least 32x32 subarrays.
        //    continue;
        //}
		CALCULATE(dataBank, MemoryType::data);
        numDesigns++;
		if (!dataBank->invalid) {
			Result tempResult;
			VERIFY_DATA_CAPACITY;
			numSolution++;
			UPDATE_BEST_DATA;
			// tempResult.printToCsvFile(outputFile);
			if (inputParameter->optimizationTarget == full_exploration && !inputParameter->isPruningEnabled) {
				OUTPUT_TO_FILE;
			}
		}
		delete dataBank; 
	}

	if (numSolution > 0) {
		Bank * trialBank;
		Result tempResult;
		/* refine local wire type */
		REFINE_LOCAL_WIRE_FORLOOP {
			localWire->Initialize(inputParameter->processNode, (WireType)localWireType,
					(WireRepeaterType)localWireRepeaterType, inputParameter->temperature,
					(bool)isLocalWireLowSwing);
			for (int i = 0; i < (int)full_exploration; i++) {
				LOAD_GLOBAL_WIRE(bestDataResults[i]);
				TRY_AND_UPDATE(bestDataResults[i], MemoryType::data);
			}
			if (inputParameter->optimizationTarget == full_exploration && !inputParameter->isPruningEnabled) {
				OUTPUT_TO_FILE;
			}
		}
		/* refine global wire type */
		REFINE_GLOBAL_WIRE_FORLOOP {
			globalWire->Initialize(inputParameter->processNode, (WireType)globalWireType,
					(WireRepeaterType)globalWireRepeaterType, inputParameter->temperature,
					(bool)isGlobalWireLowSwing);
			for (int i = 0; i < (int)full_exploration; i++) {
				LOAD_LOCAL_WIRE(bestDataResults[i]);
				TRY_AND_UPDATE(bestDataResults[i], MemoryType::data);
			}
			if (inputParameter->optimizationTarget == full_exploration && !inputParameter->isPruningEnabled) {
				OUTPUT_TO_FILE;
			}
		}
	}

	//inputParameter -> optimizationTarget = full_exploration;

	if (inputParameter->optimizationTarget == full_exploration && inputParameter->isPruningEnabled) {
		/* pruning is enabled */
		Result **** pruningResults;
		/* pruningResults[x][y][z] points to the result which is optimized for x, with constraint on y with z overhead */
		pruningResults = new Result***[(int)full_exploration];	/* full_exploration is always set as the last element in the enum, so if full_exploration is 8, what we want here is a 0-7 array, which is correct */
		for (int i = 0; i < (int)full_exploration; i++) {
			pruningResults[i] = new Result**[(int)full_exploration];
			for (int j = 0; j < (int)full_exploration; j++) {
				pruningResults[i][j] = new Result*[3];		/* 10%, 20%, and 30% overhead */
				for (int k = 0; k < 3; k++)
					pruningResults[i][j][k] = new Result;
			}
		}

		/* assign the constraints */
		for (int i = 0; i < (int)full_exploration; i++)
			for (int j = 0; j < (int)full_exploration; j++)
				for (int k = 0; k < 3; k++) {
					pruningResults[i][j][k]->optimizationTarget = (OptimizationTarget)i;
					*(pruningResults[i][j][k]->localWire) = *(bestDataResults[i].localWire);
					*(pruningResults[i][j][k]->globalWire) = *(bestDataResults[i].globalWire);
					switch ((OptimizationTarget)j) {
					case read_latency_optimized:
						pruningResults[i][j][k]->limitReadLatency = bestDataResults[j].bank->readLatency * (1 + (k + 1.0) / 10);
						break;
					case write_latency_optimized:
						pruningResults[i][j][k]->limitWriteLatency = bestDataResults[j].bank->writeLatency * (1 + (k + 1.0) / 10);
						break;
					case read_energy_optimized:
						pruningResults[i][j][k]->limitReadDynamicEnergy = bestDataResults[j].bank->readDynamicEnergy * (1 + (k + 1.0) / 10);
						break;
					case write_energy_optimized:
						pruningResults[i][j][k]->limitWriteDynamicEnergy = bestDataResults[j].bank->writeDynamicEnergy * (1 + (k + 1.0) / 10);
						break;
					case read_edp_optimized:
						pruningResults[i][j][k]->limitReadEdp = bestDataResults[j].bank->readLatency * bestDataResults[j].bank->readDynamicEnergy * (1 + (k + 1.0) / 10);
						break;
					case write_edp_optimized:
						pruningResults[i][j][k]->limitWriteEdp = bestDataResults[j].bank->writeLatency * bestDataResults[j].bank->writeDynamicEnergy * (1 + (k + 1.0) / 10);
						break;
					case read_bandwidth_optimized:
						pruningResults[i][j][k]->limitReadBandwidth = bestDataResults[j].getReadBandwidth() / (1 + (k + 1.0) / 10);
						break;
					case write_bandwidth_optimized:
						pruningResults[i][j][k]->limitWriteBandwidth = bestDataResults[j].getWriteBandwidth() / (1 + (k + 1.0) / 10);
						break;
					case area_optimized:
						pruningResults[i][j][k]->limitArea = bestDataResults[j].bank->area * (1 + (k + 1.0) / 10);
						break;
					case leakage_optimized:
						pruningResults[i][j][k]->limitLeakage = bestDataResults[j].bank->leakage * (1 + (k + 1.0) / 10);
						break;
					default:
						/* nothing should happen here */
						cout << "Warning: should not happen" << endl;
					}
				}

		for (int i = 0; i < (int)full_exploration; i++) {
			bestDataResults[i].printAsCacheToCsvFile(bestTagResults[i], inputParameter->cacheAccessMode, outputFile);
			//bestDataResults[i].printToCsvFile(outputFile);
		}
		cout << "Pruning done" << endl;
		/* Run pruning here */
		/* TO-DO */

		/* delete */
		for (int i = 0; i < (int)full_exploration; i++) {
			for (int j = 0; j < (int)full_exploration; j++) {
				for (int k = 0; k < 3; k++)
					delete pruningResults[i][j][k];
				delete [] pruningResults[i][j];
			}
			delete [] pruningResults[i];
		}
	}

	/* If design constraint is applied */
	if (inputParameter->optimizationTarget != full_exploration && inputParameter->isConstraintApplied) {
		double allowedDataReadLatency = bestDataResults[read_latency_optimized].bank->readLatency * (inputParameter->readLatencyConstraint + 1);
		double allowedDataWriteLatency = bestDataResults[write_latency_optimized].bank->writeLatency * (inputParameter->writeLatencyConstraint + 1);
		double allowedDataReadDynamicEnergy = bestDataResults[read_energy_optimized].bank->readDynamicEnergy * (inputParameter->readDynamicEnergyConstraint + 1);
		double allowedDataWriteDynamicEnergy = bestDataResults[write_energy_optimized].bank->writeDynamicEnergy * (inputParameter->writeDynamicEnergyConstraint + 1);
		double allowedDataLeakage = bestDataResults[leakage_optimized].bank->leakage * (inputParameter->leakageConstraint + 1);
		double allowedDataArea = bestDataResults[area_optimized].bank->area * (inputParameter->areaConstraint + 1);
		double allowedDataReadEdp = bestDataResults[read_edp_optimized].bank->readLatency
				* bestDataResults[read_edp_optimized].bank->readDynamicEnergy * (inputParameter->readEdpConstraint + 1);
		double allowedDataWriteEdp = bestDataResults[write_edp_optimized].bank->writeLatency
				* bestDataResults[write_edp_optimized].bank->writeDynamicEnergy * (inputParameter->writeEdpConstraint + 1);
		for (int i = 0; i < (int)full_exploration; i++) {
			APPLY_LIMIT(bestDataResults[i]);
		}

		numSolution = 0;
		INITIAL_BASIC_WIRE;
		BIGFOR {
			if (blockSize / (numActiveSubArrayPerRow * numActiveSubArrayPerColumn * numActiveMatPerRow * numActiveMatPerColumn) == 0) {
				/* To aggressive partitioning */
				continue;
			}
			CALCULATE(dataBank, MemoryType::data);
            numDesigns++;
			if (!dataBank->invalid && dataBank->readLatency <= allowedDataReadLatency && dataBank->writeLatency <= allowedDataWriteLatency
					&& dataBank->readDynamicEnergy <= allowedDataReadDynamicEnergy && dataBank->writeDynamicEnergy <= allowedDataWriteDynamicEnergy
					&& dataBank->leakage <= allowedDataLeakage && dataBank->area <= allowedDataArea
					&& dataBank->readLatency * dataBank->readDynamicEnergy <= allowedDataReadEdp && dataBank->writeLatency * dataBank->writeDynamicEnergy <= allowedDataWriteEdp) {
				Result tempResult;
				VERIFY_DATA_CAPACITY;
				numSolution++;
				UPDATE_BEST_DATA;
				tempResult.printToCsvFile(outputFile);
			}
			delete dataBank;
		}
	}

    cout << "numSolutions = " << numSolution << " / numDesigns = " << numDesigns << endl;
	globalWire->PrintProperty();

	if (localWire) delete localWire;
	if (globalWire) delete globalWire;

    return 0;
}

void applyConstraint() {
	/* Check functions that are not yet implemented */
	if (inputParameter->designTarget == CAM_chip) {
		cout << "[ERROR] CAM model is still under development" << endl;
		exit(-1);
	}
	if (cell->memCellType == MLCNAND) {
		cout << "[ERROR] MLC NAND flash model is still under development" << endl;
		exit(-1);
	}

	if (inputParameter->designTarget != cache && inputParameter->associativity > 1) {
		cout << "[WARNING] Associativity setting is ignored for non-cache designs" << endl;
		inputParameter->associativity = 1;
	}

	if (!isPow2(inputParameter->associativity)) {
		cout << "[ERROR] The associativity value has to be a power of 2 in this version" << endl;
		//exit(-1);
	}

	if (inputParameter->routingMode == h_tree && inputParameter->internalSensing == false) {
		cout << "[ERROR] H-tree does not support external sensing scheme in this version" << endl;
		exit(-1);
	}
/*
	if (inputParameter->globalWireRepeaterType != repeated_none && inputParameter->internalSensing == false) {
		cout << "[ERROR] Repeated global wire does not support external sensing scheme" << endl;
		exit(-1);
	}
*/

	/* TO-DO: more rules to add here */
}

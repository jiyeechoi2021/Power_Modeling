// This file contains code from NVSim, (c) 2012-2013,  Pennsylvania State University 
//and Hewlett-Packard Company. See LICENSE_NVSim file in the top-level directory.
//No part of DESTINY Project, including this file, may be copied,
//modified, propagated, or distributed except according to the terms
//contained in the LICENSE file.


#include "Mux.h"
#include "global.h"
#include "formula.h"

Mux::Mux()
	: FunctionUnit(),
	  initialized(false),
	  numInput(0),
	  numMux(0),
	  capLoad(0),
	  capInputNextStage(0),
	  minDriverCurrent(0),
	  capOutput(0),
	  widthNMOSPassTransistor(0),
	  resNMOSPassTransistor(0),
	  capNMOSPassTransistor(0),
	  capForPreviousDelayCalculation(0),
	  capForPreviousPowerCalculation(0),
	  rampInput(0),
	  rampOutput(0) {
}

Mux::~Mux() {
	// TODO Auto-generated destructor stub
}

void Mux::Initialize(int _numInput, long long _numMux, double _capLoad, double _capInputNextStage, double _minDriverCurrent){
	if (initialized)
		cout << "[Mux] Warning: Already initialized!" << endl;

	double resCellAccess = CalculateOnResistance(cell->widthAccessCMOS * ((tech->featureSize <= 14)? 2:1) * tech->featureSize, NMOS, inputParameter->temperature, *tech);

	numInput = _numInput;
	numMux = _numMux;
	capLoad = _capLoad;
	capInputNextStage = _capInputNextStage;
	minDriverCurrent = _minDriverCurrent;

	if ((numInput > 1) && (numMux > 0 )) {
		double minNMOSWidth = minDriverCurrent / tech->currentOnNmos[inputParameter->temperature - 300];
		if (cell->memCellType == MRAM || cell->memCellType == PCRAM || cell->memCellType == memristor) {
			/* Mux resistance should be small enough for voltage dividing */
			double maxResNMOSPassTransistor = cell->resistanceOn * IR_DROP_TOLERANCE;
	    	if(tech->featureSize >= 22* 1e-9) widthNMOSPassTransistor = CalculateOnResistance(tech->featureSize, NMOS, inputParameter->temperature, *tech)
					* tech->featureSize / maxResNMOSPassTransistor;
			else{ widthNMOSPassTransistor = CalculateOnResistance_normal(((tech->featureSize <= 14* 1e-9)? 2:1)*tech->featureSize, NMOS, inputParameter->temperature, *tech)
								* tech->featureSize / (resCellAccess*2);
				widthNMOSPassTransistor = 2* ceil(widthNMOSPassTransistor/tech->featureSize) * tech->featureSize;
			}
			if (widthNMOSPassTransistor > inputParameter->maxNmosSize * tech->featureSize) {	// Change the transistor size to avoid severe IR drop
	    		widthNMOSPassTransistor = inputParameter->maxNmosSize * tech->featureSize;
	    	}
			widthNMOSPassTransistor = MAX(MAX(widthNMOSPassTransistor,minNMOSWidth), 6 * MIN_NMOS_SIZE * tech->featureSize);
		} else {
			widthNMOSPassTransistor = MAX(6 * MIN_NMOS_SIZE * tech->featureSize, minNMOSWidth);
		}
		double temp = 0;
		EnlargeSize(&widthNMOSPassTransistor, &temp, tech->featureSize * MAX_TRANSISTOR_HEIGHT, *tech);
	}

	initialized = true;
}

void Mux::CalculateArea(){
	if (!initialized) {
		cout << "[Mux] Error: Require initialization first!" << endl;
	} else {
		if ((numInput > 1) && (numMux > 0 )) {
			double h,w;
			CalculateGateArea(INV, 1, ((tech->featureSize <= 14*1e-9)? 2:1) * widthNMOSPassTransistor, 0, tech->featureSize*40, *tech, &h, &w);
			width = numMux * numInput * w;
			height = h;
			area = width * height;
		} else {
			height = width = area = 0;
		}
	}
}

void Mux::CalculateRC() {
	if (!initialized) {
		cout << "[Mux] Error: Require initialization first!" << endl;
	} else {
		if ((numInput > 1) && (numMux > 0 )) {
			capNMOSPassTransistor = CalculateDrainCap(((tech->featureSize <= 14*1e-9)? 2:1) * widthNMOSPassTransistor, NMOS, tech->featureSize*40, *tech);
			capForPreviousPowerCalculation = capNMOSPassTransistor;
			capOutput = numInput * capNMOSPassTransistor;
			capForPreviousDelayCalculation = capOutput + capNMOSPassTransistor + capLoad;
			resNMOSPassTransistor = CalculateOnResistance(((tech->featureSize <= 14*1e-9)? 2:1) * widthNMOSPassTransistor, NMOS, inputParameter->temperature, *tech);
		} else {
			;	/* nothing to do */
		}
	}
}

void Mux::CalculateLatency(double _rampInput) {  //rampInput is actually useless in Mux module
	if (!initialized) {
		cout << "[Mux] Error: Require initialization first!" << endl;
	} else {
		if ((numInput > 1) && (numMux > 0 )) {
			rampInput = _rampInput;
			double tr;
			tr = resNMOSPassTransistor * (capOutput + capLoad);
			readLatency = 2.3 * tr;
			writeLatency = readLatency;
		} else {
			readLatency = writeLatency = 0;
		}
	}
}

void Mux::CalculatePower() {
	if (!initialized) {
		cout << "[Mux] Error: Require initialization first!" << endl;
	} else {
		if ((numInput > 1) && (numMux > 0 )) {
			leakage = 0; //TO-DO
			readDynamicEnergy = (capOutput + capInputNextStage) * tech->vdd * (tech->vdd - tech->vth);
			readDynamicEnergy *= numMux;  //worst-case dynamic power analysis
			writeDynamicEnergy = readDynamicEnergy;
		} else {
			readDynamicEnergy = writeDynamicEnergy = leakage = 0;
		}
	}
}

void Mux::PrintProperty() {
	cout << "Mux Properties:" << endl;
	FunctionUnit::PrintProperty();
}

Mux & Mux::operator=(const Mux &rhs) = default;
